package com.demo.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims.entity.User;
import com.demo.ims.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository rep;
	
	public User addUser(User user) {
		System.out.println(user.getMobile());
		return rep.save(user);
	}
}
