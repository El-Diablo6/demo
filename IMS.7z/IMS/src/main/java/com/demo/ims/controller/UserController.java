package com.demo.ims.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.ims.entity.User;
import com.demo.ims.service.UserService;

@Controller
@RequestMapping("/ims/api")
public class UserController {

	@Autowired
	UserService service;
	
	@PostMapping("/add")
	public String add(@ModelAttribute User user,Model model) {
		model.addAttribute("user",user);
		service.addUser(user);
		return "forward:/WEB-INF/views/register-success.jsp";
	}
	
	@GetMapping	("/cus-login")
	public String cusLogin() {
		return "cus-login";
	}
}
