package com.demo.ims.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims.entity.User;
import com.demo.ims.service.UserService;

@RestController
@RequestMapping("/ims/api")
public class UserController {

	@Autowired
	UserService service;
	
	@PostMapping("/add")
	public User add(@ModelAttribute User user) {
		System.out.println(user);
		return service.addUser(user);
	}
}
