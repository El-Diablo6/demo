package com.demo.ims_client.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.demo.ims_client.model.User;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	RestTemplate template;
	
    @Value("${url}")
    private String stringUrl;
	
	@GetMapping("/register")
	public String register() {
		return "userRegistration";
	}
	
	@GetMapping("/login")
	public String login() {
		return "userLogin";
	}
	
	@PostMapping("/registerUser")
	public String register(@ModelAttribute User user) {
		String url = stringUrl+"/addUser";
		
		 HttpEntity<User> requestEntity = new HttpEntity<>(user);

		    ResponseEntity<User> response = template.exchange(
		            url,
		            HttpMethod.POST,
		            requestEntity,
		            User.class
		    );
		    return "register-success";
	}
	
	@PostMapping("/loginUser")
	public String userLogin(@ModelAttribute User user) {
		String url = stringUrl+"/userLogin";
		System.out.println(user);
		HttpEntity<User> requestEntity = new HttpEntity<>(user);

	    ResponseEntity<Boolean> response = template.exchange(
	            url,
	            HttpMethod.POST,
	            requestEntity,
	            Boolean.class
	    );
	    System.out.println(response.getBody());
	    
	    return "userRegistration";
	}
}
