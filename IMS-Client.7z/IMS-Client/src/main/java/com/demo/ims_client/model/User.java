package com.demo.ims_client.model;

public record User(String id, String name, String email, String mobile, String address, String password, String role) {

}
