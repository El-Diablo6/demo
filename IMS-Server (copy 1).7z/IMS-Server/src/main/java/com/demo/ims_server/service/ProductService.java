package com.demo.ims_server.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims_server.entity.Product;
import com.demo.ims_server.entity.Vendor;
import com.demo.ims_server.entity.VendorInvoice;
import com.demo.ims_server.repository.ProductRepository;
import com.demo.ims_server.repository.VendorRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository rep;
	
	@Autowired
	VendorRepository vrep;
	
	public boolean checkId(String id) {
		return rep.existsById(id);
	}
	
	public Product addProduct(Product product) {
		return rep.save(product);
	}
	
	 public Product updateProduct(Product product) {
	        if (rep.existsById(product.getId())) {
	            return rep.save(product);
	        } else {
	            return null;
	        }
	    }

	    public boolean deleteProduct(String id) {
	        if (rep.existsById(id)) {
	            rep.deleteById(id);
	            return true;
	        } else {
	            return false;
	        }
	    }
	    
	    public VendorInvoice generateVendorInvoice(String vendorId) {
	    	Optional<Vendor> op = vrep.findById(vendorId);
	    	if(op.isPresent() && op.get().getStatus().equalsIgnoreCase("pending")) {
	    		Product product = rep.findByVendorId(vendorId);
	    		VendorInvoice vendor = new VendorInvoice();
	    		vendor.setVendorId(vendorId);
	    		vendor.setPid(product.getId());
	    		vendor.setPname(product.getName());
	    		vendor.setPrice(product.getPrice());
	    		vendor.setDescription(product.getDescription());
	    		vendor.setQuantity(product.getQuantity());
	    		vendor.setName(op.get().getName());
	    		vendor.setEmail(op.get().getEmail());
	    		vendor.setMobile(op.get().getMobile());
	    		vendor.setAddress(op.get().getAddress());
	    		vendor.setStatus(op.get().getStatus());
	    		return vendor;	    		
	    	}else {
	    		return null;
	    	}
	    }
	    
	    public List<Product> display(){
	    	List<Product> filteredProducts = null;
	    	List<Product> products = rep.findAll();
	    	if(!(products.isEmpty())) {
	    		for(Product prod : products) {
	    			if(prod.getQuantity()!=0) {
	    				filteredProducts.add(prod);
	    			}
	    		}
	    		return filteredProducts;
	    	}
	    	return null;
	    }
}
