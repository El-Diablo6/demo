package com.demo.ims_server.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims_server.entity.Vendor;
import com.demo.ims_server.repository.VendorRepository;

@Service
public class VendorService {


	@Autowired
	VendorRepository rep;
	
	public boolean checkId(String id) {
		return rep.existsById(id);
	}
	
	public Vendor addVendor(Vendor vendor) {
		return rep.save(vendor);
	}
	
	 public Vendor updateVendor(Vendor vendor) {
	        if (rep.existsById(vendor.getId())) {
	            return rep.save(vendor);
	        } else {
	            return null;
	        }
	    }

	    // Delete Vendor
	    public String deleteVendor(String id) {
	    	Optional<Vendor> optional = rep.findById(id);
	        if (optional.isPresent()) {
	        	if(!(optional.get().getStatus().equalsIgnoreCase("pending"))) {
	        		rep.deleteById(id);
	        		return "Vendor with ID " + id + " was deleted successfully.";	        		
	        	}else {
	        		return "Vendor with ID " + id + " cannot be deleted";
	        	}
	        } else {
	            return "Vendor with ID " + id + " not found.";
	        }
	    }
	    
	    public List<Vendor> displayAllVendors(){
	    	return rep.findAll();
	    }
}
