package com.demo.ims_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImsServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImsServerApplication.class, args);
	}

}
