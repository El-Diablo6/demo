package com.demo.ims.entity;

public class VendorInvoice {
	private String name, email, mobile, address, status;
	private String pid;
	private String pname, description, vendorId;
	private long quantity;
	private double price;
	public VendorInvoice(String name, String email, String mobile, String address, String status, String pid,
			String pname, String description, String vendorId, long quantity, double price) {
		super();
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.status = status;
		this.pid = pid;
		this.pname = pname;
		this.description = description;
		this.vendorId = vendorId;
		this.quantity = quantity;
		this.price = price;
	}
	public VendorInvoice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "VendorInvoice [name=" + name + ", email=" + email + ", mobile=" + mobile + ", address="
				+ address + ", status=" + status + ", pid=" + pid + ", pname=" + pname + ", description=" + description
				+ ", vendorId=" + vendorId + ", quantity=" + quantity + ", price=" + price + "]";
	}
	
	
}
