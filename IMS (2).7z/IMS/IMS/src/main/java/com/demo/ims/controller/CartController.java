package com.demo.ims.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims.entity.Cart;
import com.demo.ims.entity.UserInvoice;
import com.demo.ims.service.CartService;

@RestController
@RequestMapping("/ims/api")
public class CartController {
	
	@Autowired
	CartService service;
	
	@PostMapping("{userId}/addCart")
	public Cart addToCart(@RequestParam String productId, @PathVariable String userId, @RequestParam int quantity) {
		return service.addItem(productId, userId, quantity);
	}

  @GetMapping("{userId}/generateUserInvoice")
  public ResponseEntity<?> generate(@PathVariable String userId) {
  	UserInvoice user =  service.generateUserInvoice(userId);
  	 if (user == null) {
  	        return ResponseEntity.status(HttpStatus.NOT_FOUND)
  	                             .body("No Invoice found for user with ID: " + userId);
  	    } else {
  	        return ResponseEntity.ok(user);
  	    }
  }
}
