package com.demo.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims.entity.Vendor;
import com.demo.ims.repository.VendorRepository;

@Service
public class VendorService {


	@Autowired
	VendorRepository rep;
	
	public Vendor addVendor(Vendor vendor) {
		return rep.save(vendor);
	}
	
	 public Vendor updateVendor(Vendor vendor) {
	        if (rep.existsById(vendor.getId())) {
	            return rep.save(vendor);
	        } else {
	            return null;
	        }
	    }

	    // Delete Vendor
	    public boolean deleteVendor(String id) {
	        if (rep.existsById(id)) {
	            rep.deleteById(id);
	            return true;
	        } else {
	            return false;
	        }
	    }
}
