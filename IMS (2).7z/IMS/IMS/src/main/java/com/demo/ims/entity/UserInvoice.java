package com.demo.ims.entity;

public class UserInvoice {
	private String userId, name, email, mobile, address,status;
	private String productId;
	private int quantity;
	private String pname, description, vendorId;
	private double price;
	private String vname, vemail, vmobile, vaddress;
	
	public UserInvoice(String userId, String name, String email, String mobile, String address, String status,
			String productId, int quantity, String pname, String description, String vendorId, double price,
			String vname, String vemail, String vmobile, String vaddress) {
		super();
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.status = status;
		this.productId = productId;
		this.quantity = quantity;
		this.pname = pname;
		this.description = description;
		this.vendorId = vendorId;
		this.price = price;
		this.vname = vname;
		this.vemail = vemail;
		this.vmobile = vmobile;
		this.vaddress = vaddress;
	}
	public UserInvoice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getVemail() {
		return vemail;
	}
	public void setVemail(String vemail) {
		this.vemail = vemail;
	}
	public String getVmobile() {
		return vmobile;
	}
	public void setVmobile(String vmobile) {
		this.vmobile = vmobile;
	}
	public String getVaddress() {
		return vaddress;
	}
	public void setVaddress(String vaddress) {
		this.vaddress = vaddress;
	}
	@Override
	public String toString() {
		return "UserInvoice [userId=" + userId + ", name=" + name + ", email=" + email + ", mobile=" + mobile
				+ ", address=" + address + ", status=" + status + ", productId=" + productId + ", quantity=" + quantity
				+ ", pname=" + pname + ", description=" + description + ", vendorId=" + vendorId + ", price=" + price
				+ ", vname=" + vname + ", vemail=" + vemail + ", vmobile=" + vmobile + ", vaddress=" + vaddress + "]";
	}
	
	
}
