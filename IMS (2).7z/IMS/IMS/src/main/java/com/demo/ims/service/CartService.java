package com.demo.ims.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims.entity.Cart;
import com.demo.ims.entity.Product;
import com.demo.ims.entity.User;
import com.demo.ims.entity.UserInvoice;
import com.demo.ims.entity.Vendor;
import com.demo.ims.repository.CartRepository;
import com.demo.ims.repository.ProductRepository;
import com.demo.ims.repository.UserRepository;
import com.demo.ims.repository.VendorRepository;

@Service
public class CartService {

	@Autowired
	CartRepository rep;
	
	@Autowired
	ProductRepository prep;
	
	@Autowired
	VendorRepository vrep;
	
	@Autowired
	UserRepository urep;
	
	public Cart addItem(String productId, String userId, int quantity) {
		Cart cart = new Cart();
		Optional<Product> op = prep.findById(productId);
		if(op.isPresent()) {
			cart.setProductId(productId);
			cart.setQuantity(quantity);
			cart.setStatus("pending");
			cart.setUserId(userId);
			cart.setVendorId(op.get().getVendorId());
			return rep.save(cart);
		}else {
			return null;
		}
	}
	
    public UserInvoice generateUserInvoice(String userId) {
    	UserInvoice user = new UserInvoice();
    	Cart cart = rep.findByUserId(userId);
    	Optional<User> uop = urep.findById(userId);
    	Optional<Product> pop = prep.findById(cart.getProductId());
    	Optional<Vendor> vop = vrep.findById(cart.getVendorId());
    	user.setUserId(userId);
    	user.setName(uop.get().getName());
    	user.setEmail(uop.get().getEmail());
    	user.setMobile(uop.get().getMobile());
    	user.setAddress(uop.get().getAddress());
    	user.setProductId(pop.get().getId());
    	user.setPname(pop.get().getName());
    	user.setDescription(pop.get().getDescription());
    	user.setVendorId(pop.get().getVendorId());
    	user.setQuantity(cart.getQuantity());
    	user.setPrice((cart.getQuantity() * pop.get().getPrice()));
    	user.setStatus(cart.getStatus());
    	user.setVname(vop.get().getName());
    	user.setVemail(vop.get().getEmail());
    	user.setVmobile(vop.get().getMobile());
    	user.setVaddress(vop.get().getAddress());
    	return user;
    	
    }
}
