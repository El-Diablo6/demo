package com.demo.ims.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims.entity.User;
import com.demo.ims.service.UserService;

@RestController
@RequestMapping("/ims/api")
public class UserController {

	@Autowired
	UserService service;
	
	@PostMapping("/addUser")
	public User addUser(@RequestBody User user) {
		System.out.println(user.toString());
	    return service.addUser(user);
	}
	
	@PutMapping("/updateUser")
	public User updateUser(@RequestBody User user) {
		return service.updateUser(user);
	}
	
    @DeleteMapping("/deleteUser")
    public String delete(@RequestParam String id) {
    	System.out.println(id);
        boolean deleted = service.deleteUser(id);
        if (deleted) {
            return "User with ID " + id + " was deleted successfully.";
        } else {
            return "User with ID " + id + " not found.";
        }
    }
	
}
