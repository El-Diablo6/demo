package com.demo.ims.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims.entity.Vendor;
import com.demo.ims.service.VendorService;

@RestController
@RequestMapping("/ims/api")
public class VendorController {

	@Autowired
	VendorService service;
	
	@PostMapping("/addVendor")
	public Vendor addVendor(@RequestBody Vendor vendor) {
		System.out.println(vendor.toString());
	    return service.addVendor(vendor);
	}
	
	@PutMapping("/updateVendor")
	public Vendor updateVendor(@RequestBody Vendor vendor) {
		return service.updateVendor(vendor);
	}
	
    @DeleteMapping("/deleteVendor")
    public String delete(@RequestParam String id) {
        boolean deleted = service.deleteVendor(id);
        if (deleted) {
            return "Vendor with ID " + id + " was deleted successfully.";
        } else {
            return "Vendor with ID " + id + " not found.";
        }
    }
	
}
