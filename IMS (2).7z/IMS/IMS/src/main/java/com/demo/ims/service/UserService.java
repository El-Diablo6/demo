package com.demo.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims.entity.User;
import com.demo.ims.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository rep;
	
	public User addUser(User user) {
		return rep.save(user);
	}
	
	 public User updateUser(User user) {
	        if (rep.existsById(user.getId())) {
	            return rep.save(user);
	        } else {
	            return null;
	        }
	    }


	    public boolean deleteUser(String id) {
	        if (rep.existsById(id)) {
	            rep.deleteById(id);
	            return true;
	        } else {
	            return false;
	        }
	    }
	    
}
