package com.demo.ims_server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims_server.entity.User;
import com.demo.ims_server.service.UserService;

@CrossOrigin(origins = "http://localhost:9080/")
@RestController
@RequestMapping("/ims/api")
public class UserController {

	@Autowired
	UserService service;

	@GetMapping("/checkUserId")
	public ResponseEntity<String> check(@RequestParam String id) {
		boolean idExists = service.checkId(id);

	    if (idExists) {
	        return ResponseEntity.status(HttpStatus.OK).body(id);
	    } else {
	        return ResponseEntity.status(HttpStatus.OK).body("");
	    }

	}
	
	@GetMapping("/checkEmail")
	public ResponseEntity<String> checkMail(@RequestParam String mail) {
		boolean emailExists = service.checkMail(mail);

	    if (emailExists) {
	        return ResponseEntity.status(HttpStatus.OK).body(mail);
	    } else {
	        return ResponseEntity.status(HttpStatus.OK).body("");
	    }
	}

	@GetMapping("/checkPhone")
	public ResponseEntity<String> checkPhone(@RequestParam String phone) {
		boolean phoneExists = service.checkPhone(phone);

	    if (phoneExists) {
	        return ResponseEntity.status(HttpStatus.OK).body(phone);
	    } else {
	        return ResponseEntity.status(HttpStatus.OK).body("");
	    }
	}

	@PostMapping("/addUser")
	public User addUser(@RequestBody User user) {
		return service.addUser(user);
	}

	@PostMapping("/login")
	public boolean login(@RequestBody User user) {
		return service.login(user);
	}

	@PutMapping("/updateUser")
	public User updateUser(@RequestBody User user) {
		return service.updateUser(user);
	}

	@DeleteMapping("/deleteUser")
	public String delete(@RequestParam String id) {
		System.out.println(id);
		String str = service.deleteUser(id);
		return str;
	}

	@GetMapping("/displayUsers")
	public ResponseEntity<?> display() {
		List<User> users = service.displayAllUsers();
		if (users.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("There are currently no users registered in the system.");
		} else {
			return ResponseEntity.ok(users);
		}
	}

}
