package com.demo.ims_server.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.ims_server.entity.Cart;

@Repository
public interface CartRepository extends JpaRepository<Cart,Long>{
	List<Cart> findByUserId(String userId);
	Cart findByUserIdAndProductId(String userId, String productId);
}
