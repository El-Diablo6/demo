package com.demo.ims_server.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.ims_server.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User,String>{
	boolean findByMobile(String mobile);
	boolean findByEmail(String email);
	Optional<User> findByIdOrEmail(String Id, String email);

}
