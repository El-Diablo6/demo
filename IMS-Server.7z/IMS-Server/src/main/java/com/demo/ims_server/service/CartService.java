package com.demo.ims_server.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims_server.entity.Cart;
import com.demo.ims_server.entity.Product;
import com.demo.ims_server.entity.User;
import com.demo.ims_server.entity.UserInvoice;
import com.demo.ims_server.entity.Vendor;
import com.demo.ims_server.repository.CartRepository;
import com.demo.ims_server.repository.ProductRepository;
import com.demo.ims_server.repository.UserRepository;
import com.demo.ims_server.repository.VendorRepository;

@Service
public class CartService {

	@Autowired
	CartRepository rep;

	@Autowired
	ProductRepository prep;

	@Autowired
	VendorRepository vrep;

	@Autowired
	UserRepository urep;

	public Cart addItem(String productId, String userId, int quantity) {
		List<Cart> carts = rep.findByUserId(userId);
		Cart cart = new Cart();
		for(Cart oldCart : carts) {
			if (oldCart.getProductId().equalsIgnoreCase(productId)) {
				cart.setId(oldCart.getId());
				cart.setProductId(productId);
				cart.setUserId(userId);
				cart.setVendorId(oldCart.getVendorId());
				cart.setStatus("pending");
				cart.setQuantity(oldCart.getQuantity() + quantity);
				return rep.save(cart);
			}
		}
			Optional<Product> op = prep.findById(productId);
			if (op.isPresent()) {
				cart.setProductId(productId);
				cart.setQuantity(quantity);
				cart.setStatus("pending");
				cart.setUserId(userId);
				cart.setVendorId(op.get().getVendorId());
				return rep.save(cart);
			}else {
				return null;
			}
	}

	public boolean deleteProduct(String userId, String productId) {
		Cart cart = rep.findByUserIdAndProductId(userId, productId);
		if (rep.existsById(cart.getId())) {
			rep.deleteById(cart.getId());
			return true;
		} else {
			return false;
		}
	}

	public List<UserInvoice> generateUserInvoice(String userId) {
		List<UserInvoice> invoiceList = new ArrayList<UserInvoice>();
		List<Cart> carts = rep.findByUserId(userId);
		for (Cart cart : carts) {
			UserInvoice user = new UserInvoice();
			if (cart.getStatus().equalsIgnoreCase("pending")) {
				Optional<User> uop = urep.findById(userId);
				Optional<Product> pop = prep.findById(cart.getProductId());
				Optional<Vendor> vop = vrep.findById(cart.getVendorId());
				user.setUserId(userId);
				user.setName(uop.get().getName());
				user.setEmail(uop.get().getEmail());
				user.setMobile(uop.get().getMobile());
				user.setAddress(uop.get().getAddress());
				user.setProductId(pop.get().getId());
				user.setPname(pop.get().getName());
				user.setDescription(pop.get().getDescription());
				user.setVendorId(pop.get().getVendorId());
				user.setQuantity(cart.getQuantity());
				user.setPrice((cart.getQuantity() * pop.get().getPrice()));
				user.setStatus(cart.getStatus());
				user.setVname(vop.get().getName());
				user.setVemail(vop.get().getEmail());
				user.setVmobile(vop.get().getMobile());
				user.setVaddress(vop.get().getAddress());
				System.out.println(user.toString());
				invoiceList.add(user);
			}
		}
		if(invoiceList.isEmpty()) {
			return null;			
		}else {
			return invoiceList;
		}
	}
}
