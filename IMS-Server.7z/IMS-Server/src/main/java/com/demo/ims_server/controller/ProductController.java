package com.demo.ims_server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims_server.entity.Product;
import com.demo.ims_server.entity.VendorInvoice;
import com.demo.ims_server.service.ProductService;

@RestController
@RequestMapping("/ims/api")
public class ProductController {
	@Autowired
	ProductService service;
	
	@GetMapping("/checkProductId")
	public boolean check(@RequestParam String id) {
		boolean val = service.checkId(id);
		if(val) {
			return true;
		}else {
			return false;
		}
	}
	
	@PostMapping("/addProduct")
	public Product addProduct(@RequestBody Product product) {
		System.out.println(product.toString());
	    return service.addProduct(product);
	}
	
	@PutMapping("/updateProduct")
	public Product updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}
	
    @DeleteMapping("/deleteProduct")
    public String delete(@RequestParam String id) {
    	System.out.println(id);
        boolean deleted = service.deleteProduct(id);
        if (deleted) {
            return "Product with ID " + id + " was deleted successfully.";
        } else {
            return "Product with ID " + id + " not found.";
        }
    }
    
    @GetMapping("/generateVendorInvoice")
    public ResponseEntity<?> generate(@RequestParam String vendorId) {
    	VendorInvoice vendor =  service.generateVendorInvoice(vendorId);
    	 if (vendor == null) {
    	        return ResponseEntity.status(HttpStatus.NOT_FOUND)
    	                             .body("No Invoice found for vendor with ID: " + vendorId);
    	    } else {
    	        return ResponseEntity.ok(vendor);
    	    }
    }
	
    @GetMapping("/display")
    public List<Product> method(){
    	return service.display();
    }
}
