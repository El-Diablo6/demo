package com.demo.ims_server.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.ims_server.entity.Cart;
import com.demo.ims_server.entity.User;
import com.demo.ims_server.repository.CartRepository;
import com.demo.ims_server.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository rep;

	@Autowired
	CartRepository crep;

	public boolean checkId(String id) {
		return rep.existsById(id);
	}

	public boolean checkMail(String mail) {
		return rep.existsByEmail(mail);
	}

	public boolean checkPhone(String phone) {
		return rep.existsBymobile(phone);
	}

	public boolean login(User user) {
		Optional<User> optional = rep.findByIdOrEmail(user.getId(), user.getEmail());
		if (optional.isPresent()) {
			if (user.getPassword().equals(optional.get().getPassword())
					&& user.getRole().equalsIgnoreCase(optional.get().getRole())) {
				return true;
			}
		}
		return false;
	}

	public User addUser(User user) {
		return rep.save(user);
	}

	public User updateUser(User user) {
		if (rep.existsById(user.getId())) {
			return rep.save(user);
		} else {
			return null;
		}
	}

	public String deleteUser(String id) {
		if (rep.existsById(id)) {
			List<Cart> carts = crep.findByUserId(id);
			for (Cart cart : carts) {
				if (cart.getStatus().equalsIgnoreCase("pending")) {
					return "User with ID " + id + " cannot be deleted.";
				}
			}
			rep.deleteById(id);
			return "User with ID " + id + " was deleted successfully.";
		} else {
			return "User with ID " + id + " not found.";
		}
	}
	
	public List<User> displayAllUsers(){
		return rep.findAll();
	}

}
