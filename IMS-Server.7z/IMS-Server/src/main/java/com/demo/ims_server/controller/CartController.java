package com.demo.ims_server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims_server.entity.Cart;
import com.demo.ims_server.entity.UserInvoice;
import com.demo.ims_server.service.CartService;

@RestController
@RequestMapping("/ims/api")
public class CartController {
	
	@Autowired
	CartService service;
	
	@PostMapping("/addCart")
	public Cart addToCart(@RequestParam String productId, @RequestParam String userId, @RequestParam int quantity) {
		return service.addItem(productId, userId, quantity);
	}
	
	@DeleteMapping("/deleteCart")
	public String delete(@RequestParam String productId, @RequestParam String userId) {
        boolean deleted = service.deleteProduct(userId, productId);
        if (deleted) {
            return "Product with ID " + productId + " removed successfully.";
        } else {
            return "Product with ID " + productId + " not found.";
        }
    }

  @GetMapping("/generateUserInvoice")
  public ResponseEntity<?> generate(@RequestParam String userId) {
  	List<UserInvoice> invoice =  service.generateUserInvoice(userId);
  	 if (invoice == null) {
  	        return ResponseEntity.status(HttpStatus.NOT_FOUND)
  	                             .body("No Invoice found for user with ID: " + userId);
  	    } else {
  	        return ResponseEntity.ok(invoice);
  	    }
  }
}
