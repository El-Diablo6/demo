package com.demo.ims_server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims_server.entity.Vendor;
import com.demo.ims_server.service.VendorService;

@RestController
@RequestMapping("/ims/api")
public class VendorController {

	@Autowired
	VendorService service;
	
	@GetMapping("/checkVendorId")
	public boolean check(@RequestParam String id) {
		boolean val = service.checkId(id);
		if(val) {
			return true;
		}else {
			return false;
		}
	}
	
	@PostMapping("/addVendor")
	public Vendor addVendor(@RequestBody Vendor vendor) {
		System.out.println(vendor.toString());
	    return service.addVendor(vendor);
	}
	
	@PutMapping("/updateVendor")
	public Vendor updateVendor(@RequestBody Vendor vendor) {
		return service.updateVendor(vendor);
	}
	
    @DeleteMapping("/deleteVendor")
    public String delete(@RequestParam String id) {
        boolean deleted = service.deleteVendor(id);
        if (deleted) {
            return "Vendor with ID " + id + " was deleted successfully.";
        } else {
            return "Vendor with ID " + id + " not found.";
        }
    }
	
}
