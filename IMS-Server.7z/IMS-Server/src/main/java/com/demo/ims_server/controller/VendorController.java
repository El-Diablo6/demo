package com.demo.ims_server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.ims_server.entity.Vendor;
import com.demo.ims_server.service.VendorService;

@RestController
@RequestMapping("/ims/api")
public class VendorController {

	@Autowired
	VendorService service;
	
	@GetMapping("/checkVendorId")
	public boolean check(@RequestParam String id) {
		boolean val = service.checkId(id);
		if(val) {
			return true;
		}else {
			return false;
		}
	}
	
	@PostMapping("/addVendor")
	public Vendor addVendor(@RequestBody Vendor vendor) {
		System.out.println(vendor.toString());
	    return service.addVendor(vendor);
	}
	
	@PutMapping("/updateVendor")
	public Vendor updateVendor(@RequestBody Vendor vendor) {
		return service.updateVendor(vendor);
	}
	
    @DeleteMapping("/deleteVendor")
    public String delete(@RequestParam String id) {
        String str = service.deleteVendor(id);
        return str;
    }
    
    @GetMapping("/displayVendors")
    public ResponseEntity<?> display(){
    	List<Vendor> vendors = service.displayAllVendors();
		if (vendors.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("There are currently no vendors registered in the system.");
		} else {
			return ResponseEntity.ok(vendors);
		}
    }
	
}
